<?php
/**
 * Plugin Name: LLM-Graph Meta Tags
 * Plugin URI: https://llm-graph-hub.lovable.app/
 * Description: Adds LLM-Graph meta tags to your WordPress site so LLMs can better understand your content.
 * Version: 0.1.0
 * Author: LLM-Graph
 * Author URI: https://llm-graph-hub.lovable.app/
 * License: GPL2+
 * Text Domain: llm-graph
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class LLM_Graph_Plugin {

    const OPTION_NAME = 'llm_graph_meta_tags';

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'add_settings_page' ) );
        add_action( 'admin_init', array( $this, 'register_settings' ) );
        add_action( 'wp_head', array( $this, 'output_meta_tags' ) );
    }

    public function add_settings_page() {
        add_options_page(
            'LLM-Graph',
            'LLM-Graph',
            'manage_options',
            'llm-graph',
            array( $this, 'render_settings_page' )
        );
    }

    public function register_settings() {
        register_setting(
            'llm_graph_settings',
            self::OPTION_NAME,
            array(
                'type' => 'string',
                'sanitize_callback' => array( $this, 'sanitize_meta_tags' ),
                'default' => ''
            )
        );

        add_settings_section(
            'llm_graph_main_section',
            'LLM-Graph Meta Tags',
            function() {
                echo '<p>Add your LLM-Graph meta tags here. They will be injected into the <head> of every page.</p>';
            },
            'llm-graph'
        );

        add_settings_field(
            'llm_graph_meta_tags_field',
            'Meta tags HTML',
            array( $this, 'render_meta_tags_field' ),
            'llm-graph',
            'llm_graph_main_section'
        );
    }

    public function sanitize_meta_tags( $input ) {
        // Allow basic HTML but strip <script> tags for safety
        $input = wp_kses( $input, array(
            'meta' => array(
                'name' => true,
                'content' => true,
                'property' => true,
            ),
            'link' => array(
                'rel' => true,
                'href' => true,
            ),
        ) );
        return $input;
    }

    public function render_meta_tags_field() {
        $value = get_option( self::OPTION_NAME, '' );
        echo '<textarea name="' . esc_attr( self::OPTION_NAME ) . '" rows="10" cols="80" class="large-text code">';
        echo esc_textarea( $value );
        echo '</textarea>';
        echo '<p class="description">Paste your LLM-Graph meta tags here (for example generated from llm-graph-hub.lovable.app).</p>';
    }

    public function render_settings_page() {
        ?>
        <div class="wrap">
            <h1>LLM-Graph Settings</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields( 'llm_graph_settings' );
                do_settings_sections( 'llm-graph' );
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    public function output_meta_tags() {
        $meta = get_option( self::OPTION_NAME, '' );
        if ( ! empty( $meta ) ) {
            echo "\n<!-- LLM-Graph meta tags -->\n";
            echo $meta . "\n";
        }
    }
}

new LLM_Graph_Plugin();
