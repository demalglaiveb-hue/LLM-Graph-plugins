=== LLM-Graph Meta Tags ===
Contributors: llm-graph
Tags: ai, seo, llm, metadata
Requires at least: 5.0
Tested up to: 6.7
Stable tag: 0.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Adds LLM-Graph meta tags to your WordPress site so LLMs can better understand your content.

== Description ==

This plugin lets you paste LLM-Graph meta tags (generated from https://llm-graph-hub.lovable.app/)
into a settings page. The tags are then automatically injected into the <head> of all pages.

== Installation ==

1. Upload the `llm-graph` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Go to Settings -> LLM-Graph and paste your meta tags.
4. Save and you're done.

== Changelog ==

= 0.1.0 =
* Initial release.
