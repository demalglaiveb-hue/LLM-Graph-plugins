LLM-Graph Shopify Snippet
=========================

This package contains a simple Shopify snippet to inject LLM-Graph meta tags into your theme.

Files:
- snippets/llm-graph-meta.liquid (rename/move accordingly in your Shopify theme)

Installation:
1. In your Shopify admin, go to Online store -> Themes -> Edit code.
2. Create a new snippet named `llm-graph-meta`.
3. Paste the contents of `llm-graph-meta.liquid` into that snippet and save.
4. Open `layout/theme.liquid` (or the main layout file of your theme).
5. Inside the <head>...</head> section, add:
   {% include 'llm-graph-meta' %}
6. Replace the placeholder meta tags in the snippet with real LLM-Graph tags generated from https://llm-graph-hub.lovable.app/
